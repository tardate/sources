/* 
 *  Copyright (C) 2007, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id$
 */

package com.tardate.servletfilter;

import java.io.CharArrayWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.Enumeration;
import java.util.regex.*;

import java.io.IOException;
import java.io.PrintWriter;

import java.io.StringReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

/**
 * Demonstration servlet filter that implements header generic rewriting.
 *
 * For more information about filters, see: http://java.sun.com/products/servlet/Filters.html
 *
 * @version $Id$
 * @author 	Paul Gallagher
 */
public class EnforceContextRootFilter implements Filter
{
	private FilterConfig filterConfig;

	public void init(FilterConfig filterConfig) 
		throws ServletException {
		this.filterConfig = filterConfig;
	}
	
	public void destroy() {
		this.filterConfig = null;
	}

	public void doFilter (ServletRequest request,
	         ServletResponse response,
	         FilterChain chain)
	{
		
		try
		{
			//System.out.println ("Within Simple Filter ... Filtering the Request ...");
      HttpServletRequestWrapper requestWrapper = 
			    new HttpServletRequestWrapper(
			       (HttpServletRequest)request);
             
 		  String contextPath = requestWrapper.getContextPath();
 
		  CharResponseWrapper responseWrapper = 
		     new CharResponseWrapper(
		        (HttpServletResponse)response);
     
			chain.doFilter (requestWrapper, responseWrapper);
      
		  PrintWriter out = responseWrapper.getWriter();
		  if(responseWrapper.getContentType().equals("text/html")) {
      
		    // Get response from servlet
		    StringReader sr = new StringReader(
		       responseWrapper.toString());
		    CharArrayWriter caw = new CharArrayWriter();
        caw.write("ContextPath = " + contextPath);
        response.setContentLength(caw.toString().length());
        out.write(caw.toString());
		  } else 
		     out.write(responseWrapper.toString());
		  out.close();
						
		} catch (IOException io) {
			System.out.println ("IOException raised in EnforceContextRootFilter");
		} catch (ServletException se) {
			System.out.println ("ServletException raised in EnforceContextRootFilter");
		}
	}

	public FilterConfig getFilterConfig()
	{
		return this.filterConfig;
	}
	
	public void setFilterConfig (FilterConfig filterConfig)
	{
		this.filterConfig = filterConfig;
	}


  public class CharResponseWrapper extends
     HttpServletResponseWrapper {
     private CharArrayWriter output;
     public String toString() {
        return output.toString();
     }
     public CharResponseWrapper(HttpServletResponse response){
        super(response);
        output = new CharArrayWriter();
     }
     public PrintWriter getWriter(){
        return new PrintWriter(output);
     }
  }


class MyRequestWrapper extends HttpServletRequestWrapper {

	FilterConfig myFilterConfig;


	public MyRequestWrapper(HttpServletRequest request, FilterConfig filterConfig ){
		super(request);
		myFilterConfig = filterConfig;
	}

	public String getHeader(String name) {
		Enumeration initParams = myFilterConfig.getInitParameterNames();

		if (initParams == null) {
			// No elements to verify
			return super.getHeader(name);
		} else {
			String newHeader = super.getHeader(name);
			//System.out.print(name + " is=" + newHeader);
			try {
	
		        while (initParams.hasMoreElements())
		        {
					String paramName = (String) initParams.nextElement();
					if ( name.equalsIgnoreCase(paramName) ) {
						String[] filter = myFilterConfig.getInitParameter(paramName).split("####");
						if ( filter.length == 2 ) {
						    Pattern p = Pattern.compile(filter[0]);
	    					Matcher m = p.matcher(newHeader);
	    					newHeader = m.replaceAll(filter[1]);
						}
						break;
					}
				}
			} catch (Exception e) {
				System.out.println ("Exception raised in MyRequestWrapper");
				e.printStackTrace();
			}
			//System.out.println(" now=" + newHeader);
			return newHeader;

		}
	}

}


}

