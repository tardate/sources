package com.tardate.servletfilter;

import java.util.Enumeration;
import java.util.regex.*;
import java.io.*;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

/**
 * This is a demonstration servlet filter that performs a response rewrite to 
 * ensure that any absolute urls in the html response refer strictly to paths
 * under the application context root.
 *
 * For more information about filters, 
 * @see http://java.sun.com/products/servlet/Filters.html
 * @see http://www.ironflare.com/tutorials/filters/3.html
 * 
 * @version $Id$
 * @author 	Paul Gallagher <gallagher.paul@gmail.com>
 */
public class EnforceContextRootFilter implements Filter
{
	private FilterConfig filterConfig;

	public void init(FilterConfig filterConfig) 
		throws ServletException {
		this.filterConfig = filterConfig;
	}
	
	public void destroy() {
		this.filterConfig = null;
	}
	
	public FilterConfig getFilterConfig()
	{
		return this.filterConfig;
	}
	
	public void setFilterConfig (FilterConfig filterConfig)
	{
		this.filterConfig = filterConfig;
	}
	
	public void doFilter (ServletRequest request,
	         ServletResponse response,
	         FilterChain chain)
	{
		
		try
		{
			HttpServletRequestWrapper requestWrapper = new HttpServletRequestWrapper((HttpServletRequest)request);    

			FilteredResponseWrapper responseWrapper = new FilteredResponseWrapper(
				(HttpServletResponse) response, requestWrapper.getContextPath());
      
			chain.doFilter (requestWrapper, responseWrapper);
		  
			if(responseWrapper.getContentType().startsWith("text/html")) {
      
				OutputStream out = response.getOutputStream();
				out.write(responseWrapper.getString().getBytes());
				out.close();
        
			} else {
				OutputStream out = response.getOutputStream();
				out.write(responseWrapper.getData());
				out.close();
			}
      
		} catch (IOException io) {
			System.out.println ("IOException raised in EnforceContextRootFilter");
		} catch (ServletException se) {
			System.out.println ("ServletException raised in EnforceContextRootFilter");
			se.printStackTrace( System.out );
		}
	}

  
  public class FilteredResponseWrapper extends HttpServletResponseWrapper
  {
    private ByteArrayOutputStream output;
    private int contentLength;
    private String contentType;
    private String contextPath;
    
    public FilteredResponseWrapper(HttpServletResponse response, String contextPath)
    {
      super(response);
      output = new ByteArrayOutputStream();
      this.contextPath = contextPath.replaceFirst("/",""); // save the context path, but don't want the leading /  
    }
    public ServletOutputStream getOutputStream()
    {
      return new FilterServletOutputStream(output);
    }
    public PrintWriter getWriter()
    {
      return new PrintWriter(getOutputStream(), true);
    }
    public byte[] getData()
    {
      return output.toByteArray();
    }
    public void setContentType(String type)
    {
      this.contentType = type;
      super.setContentType(type);
    }
    public String getContentType()
    {
      return this.contentType;
    }
    public int getContentLength()
    {
      return contentLength;
    }
    public void setContentLength(int length)
    {
      this.contentLength=length;
      super.setContentLength(length);
    }  
    
    /**
     * gets response as a transformed string
     */
    public String getString()
    {
      String ctx_regex = "=\\s*[\"']/(" + contextPath + "/)?+";
      String ctx_replacement = "=\"/" + contextPath + "/";  
      return matchAndReplace(ctx_regex,output.toString(),ctx_replacement);
    }  

    /**
     * intercept redirect and ensure location mapped with context path
     */
    public void sendRedirect(java.lang.String location) throws java.io.IOException {
      String ctx_regex = "^\\s*/(" + contextPath + "/)?+";
      String ctx_replacement = "/" + contextPath + "/";  
      String new_location = matchAndReplace(ctx_regex,location,ctx_replacement);
      if (!new_location.equals(location)) System.out.println ("Intercepting sendRedirect: " + location + " |=> " + new_location);
      super.sendRedirect(new_location);                   
    }
    
    /**
     * match and replace in a string using regex
     */
    private String matchAndReplace(String p_regex, String p_test, String p_replacement) {
     Pattern p = Pattern.compile(p_regex);
     Matcher m = p.matcher(p_test);   
     return m.replaceAll(p_replacement);
    }  
  }


  public class FilterServletOutputStream extends ServletOutputStream {
    private DataOutputStream stream;
    public FilterServletOutputStream(OutputStream output)
    {
      stream=new DataOutputStream(output);
    }
    public void write(int b) throws IOException
    {
      stream.write(b);
    }
    public void write(byte[] b) throws IOException
    {
      stream.write(b);
    }
    public void write(byte[] b, int off, int len) throws IOException
    {
      stream.write(b, off, len);
    }
  }

}

