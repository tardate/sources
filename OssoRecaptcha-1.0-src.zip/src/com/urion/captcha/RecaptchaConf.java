/* 
 *  Copyright (C) 2007, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id: RecaptchaConf.java,v 1.2 2007/09/02 10:30:11 paulg Exp $
 */
package com.urion.captcha;


/**
 * recaptcha configuration support
 *
 * For more information, see: http://tardate.blogspot.com/2007/09/adding-recaptcha-to-oracle-sso.html
 *
 * @version $Id: RecaptchaConf.java,v 1.2 2007/09/02 10:30:11 paulg Exp $
 * @author 	Paul Gallagher
 */
public class RecaptchaConf
{

  // replace these with you own keys. register for keys at http://recaptcha.org
  public static String RECAPTCHA_PRIVATE_KEY = "6LcjVwAAAAAAAH2C_qlWTGSMQDp8KyQMhLYTyANR";
  public static String RECAPTCHA_PUBLIC_KEY = "6LcjVwAAAAAAAEb88MrIUI6mTgbQ2ZYlcoOZLjbQ";

}