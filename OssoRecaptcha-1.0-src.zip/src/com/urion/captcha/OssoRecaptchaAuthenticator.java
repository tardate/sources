/* 
 *  Copyright (C) 2007, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id: OssoRecaptchaAuthenticator.java,v 1.11 2007/09/02 10:30:11 paulg Exp $
 */
package com.urion.captcha;

import java.net.MalformedURLException;
import java.net.URL;
import javax.servlet.http.*;
import java.io.*;

import oracle.security.sso.server.auth.SSOServerAuth;
import oracle.security.sso.server.util.SSODebug;
import oracle.security.sso.ias904.toolkit.*;
import oracle.security.sso.ias904.toolkit.IPASAuthException;

import net.tanesha.recaptcha.*;

/**
 * Demonstration Oracle SSO authenticator that adds recaptcha support to standard OSSO authentication
 *
 * For more information, see: http://tardate.blogspot.com/2007/09/adding-recaptcha-to-oracle-sso.html
 *
 * @version $Id: OssoRecaptchaAuthenticator.java,v 1.11 2007/09/02 10:30:11 paulg Exp $
 * @author 	Paul Gallagher
 */
public class OssoRecaptchaAuthenticator 
       extends SSOServerAuth 
       implements IPASAuthInterface
{

  public OssoRecaptchaAuthenticator()
  {
  }

  public IPASUserInfo authenticate(HttpServletRequest request)
         throws IPASAuthException, IPASInsufficientCredException
  {

    SSODebug.print(SSODebug.INFO, "Processing OssoRecaptchaAuthenticator.authenticate for " + request.getRemoteAddr());

    if (request.getParameter("recaptcha_challenge_field") == null) {
      throw new IPASInsufficientCredException("");
    } else {
      // create recaptcha and test response before calling auth chain
      ReCaptcha captcha = ReCaptchaFactory.newReCaptcha(RecaptchaConf.RECAPTCHA_PUBLIC_KEY, RecaptchaConf.RECAPTCHA_PRIVATE_KEY, false);
      ReCaptchaResponse captcharesp = captcha.checkAnswer(request.getRemoteAddr(), 
                                      request.getParameter("recaptcha_challenge_field"),
                                      request.getParameter("recaptcha_response_field"));
      SSODebug.print(SSODebug.INFO, "ReCaptcha response errors = " + captcharesp.getErrorMessage());
      if (!captcharesp.isValid()) {
        throw new IPASAuthException(captcharesp.getErrorMessage());
      }
    
      return super.authenticate(request);
    } 
  }

  public URL getUserCredentialPage(HttpServletRequest request, String message)
  {
    return super.getUserCredentialPage(request, message);
  }
}

