Demonstration of Recaptcha Integration with Oracle SSO
===============================================================================

Feel free to drop me a note at gallagher.paul@gmail.com if you have any queries or
problems with this.

References
----------
	For more discussion on "why?", and links to latest distribution, see:
		http://tardate.blogspot.com/2007/09/adding-recaptcha-to-oracle-sso.html

	ReCaptcha Java Library http://tanesha.net/projects/recaptcha4j/ 	

    "Creating deployment-specific pages" http://download-west.oracle.com/docs/cd/B14099_04/manage.1012/b14078/custom.htm 

    "Integrating with Third-Party Access Management Systems" http://download-west.oracle.com/docs/cd/B14099_04/manage.1012/b14078/tpsso.htm


Distribution Contents
---------------------
OssoRecaptcha-1.0-src.zip contains:
	readme.txt - this file
	build.xml - ant build script
	build.properties - environment-specific compiler properties
	web/login.jsp - sample login page (basic)
	web/ocs.login.jsp - sample login page (from an Oracle Collaboration Suite 10g deployment)
	src/com/urion/captcha/OssoRecaptchaAuthenticator.java - customised authentication filter
	src/com/urion/captcha/RecaptchaConf.java - class to hold deployment-specific recaptcha config
	build/recaptcha4j-0.0.7.jar - current distribution of ReCaptcha Java Library
	build/OssoRecaptcha.jar - compiled customised authentication filter


Registering for recaptcha keys
------------------------------
Go to http://recaptcha.org to register and generate keys for your domain.

Keys need to be updated in src/com/urion/captcha/RecaptchaConf.java


How to Build
------------

You need Apache Ant and an Oracle AS Infrastructure (OID/SSO) environment setup

Step 1: Unzip the distribution kit into a new directory
	- update your recaptcha keys in src/com/urion/captcha/RecaptchaConf.java

Step 2: Check and revise the build.properties file
    - should just need to check ORACLE_HOME setting so that dependent libs are found

Step 3: Build using ant. There are a number of targets possible.

	ant
		- with no parameter, it will run the "all" target to compile the source
		  and generate the jar files

	ant clean
		- clean up your built files

	ant dist
		- as for "all", but also builds distribution zip

	See the build.xml for other finer-grained build/compile tasks


Customising the login page
--------------------------

The ReCaptcha Java Library (http://tanesha.net/projects/recaptcha4j/) site has the basic details
you need to include in your customised login page. You basically need to add the captcha generation
at an appropriate point:

        ...
<%
        // create recaptcha without <noscript> tags
        ReCaptcha captcha = ReCaptchaFactory.newReCaptcha("my-public-key", "my-private-key", false);
        String captchaScript = captcha.createRecaptchaHtml(request.getParameter("error"), null);
        
        out.print(captchaScript);
%>
        ...

The OssoRecaptcha distribution contains two samples:
	login.jsp - a very simple example, based on the sample distrubuted by Oracle
		found at $ORACLE_HOME/sso/lib/ipastoolkit.jar 
	ocs.login.jsp - a more "graphical" version based on Oracle's standard 
		Collaboration Suite 10g login page.


Deploying the sample site
-------------------------
The ant build file contains tasks for directly deploying your sample into the
OC4J_SECURITY application.

Note that with this approach, if you ever redeploy the OC4J_SECURITY application
(which can happen during an upgrade or patch for exmaple), then your changes 
would be destroyed.

A more robust approach would be to explode, modify and the rebuild the OC4J_SECURITY EAR file
($ORACLE_HOME/sso/lib/ossosvr.ear) once you are confident everything is working fine.
I haven't covered how you do that here.

So here's the procedure:

1. Deploy the sample files

To deploy the simple login example (using login.jsp) ...

	ant deploy

To deploy the OCS-based login example (using ocs.login.jsp) ...

	ant deploy-ocs

This essentially just performs two copy operations:
	1. Copy the login page to $ORACLE_HOME/j2ee/OC4J_SECURITY/applications/sso/web/
	2. Copy the supporting jar files to $ORACLE_HOME/j2ee/OC4J_SECURITY/applications/sso/web/WEB-INF/lib/

2. Modify the authenticator configuration

Edit $ORACLE_HOME/sso/conf/policy.properties and replace:

	MediumSecurity_AuthPlugin = oracle.security.sso.server.auth.SSOServerAuth

with:

	MediumSecurity_AuthPlugin = com.urion.captcha.OssoRecaptchaAuthenticator

You only need to do this once of course.

3. To activate the change, start/restart the OC4J_SECURITY container:

	opmnctl restartproc process-type=OC4J_SECURITY

Now you are ready to test the SSO login with integrated recaptcha. Try:

	http://you.site:port/oiddas


Debugging
---------

The debugLevel and debugFile parameters in $ORACLE_HOME/sso/conf/policy.properties
control logging bahaviour.  

For example:

#Debug level {ERROR, WARN, INFO, DEBUG}
# default debug level is set to ERROR
debugLevel = WARN

#Debug file location
#This is a mandatory property that needs to be passed
#the SSO server. A valid file location should be specified here
debugFile = /oracle01/product/10.1.2/ocs_1/sso/log/ssoServer.log

To generate log messages within the Authenticator, use the SSODebug class.
An example is used in com.urion.captcha.OssoRecaptchaAuthenticator

