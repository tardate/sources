External Filter Add-in for JDeveloper
=====================================

This project is open source (GPL). Currently being registered on sourceforge.
In the meantime, find information and sources at http://tardate.blogspot.com/2008/01/jdeveloper-filter-add-in.html


Tested and developed with 
 - JDeveloper 10.1.3.1.0
 - Extension SDK 10.1.3.36.73 (see http://www.oracle.com/technology/products/jdev/esdk/api1013/index.html )

