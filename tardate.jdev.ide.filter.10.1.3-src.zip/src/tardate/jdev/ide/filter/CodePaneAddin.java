/* 
 *  Copyright (C) 2008, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id: CodePaneAddin.java,v 1.5 2008/01/27 06:27:04 paulg Exp $
 */
package tardate.jdev.ide.filter;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;

import oracle.ide.Addin;
import oracle.ide.Context;
import oracle.ide.config.ClientSetting;
import oracle.ide.config.IdeSettings;
import oracle.ide.Ide;
import oracle.ide.controller.ContextMenu;
import oracle.ide.controller.ContextMenuListener;
import oracle.ide.controller.Controller;
import oracle.ide.controller.IdeAction;
import oracle.ide.editor.EditorManager;
import oracle.ide.log.LogManager;
import oracle.ide.model.TextNode;
import oracle.ide.model.Element;
import oracle.ide.panels.Navigable;

import oracle.ide.view.View;
import oracle.javatools.editor.BasicEditorPane;

import oracle.ide.ceditor.find.FindableEditor;

import tardate.execshell.ExecShell;

/**
 * JDeveloper filter add-in class
 * 
 * @version $Id: CodePaneAddin.java,v 1.5 2008/01/27 06:27:04 paulg Exp $
 * @author  Paul Gallagher
 */
public final class CodePaneAddin
        implements Addin, Controller
{
  // This must match the extension id used in extension.xml.
  private static final String EXTENSION_ID = "tardate.jdev.ide.filter";
  
  // allocate a command ID for actions that will be handled by this oracle.ide.Controller.
  public static final int FILTER_CMD_ID = Ide.findOrCreateCmdID("Tardate.FILTER_CMD_ID");
  
  // pop-up menu name, mnemonic and icon filename
  private static final String MENU_NAME = "Custom Text Filter";
  private static final char MENU_MNEMONIC = 'f';
  private static final String MENU_ICON = "filterIcon_16.gif";

  /**
   * Initialise the class.
   * Initialises config data (if required).
   * Creates the filter menu.
   */
  public void initialize()
  {
  	
    // get client settings for this extension
    ClientSetting clientSetting = ClientSetting.findOrCreate( EXTENSION_ID );
    if (clientSetting.getData(ConfigData.KEY) == null)
    {
      // initialize default settings if not already set
      clientSetting.putData(ConfigData.KEY, new ConfigData());
    }
    
    // register the preferences panel for this extension
    Navigable myIdeSettingsPanel = new Navigable(ConfigPanelData.TITLE, ConfigPanelData.class);
    IdeSettings.registerUI(myIdeSettingsPanel);
      	
    // create pop-up menu to invoke this extension
    JMenuItem rclickMi1 = doCreateMenuItem(this, FILTER_CMD_ID, MENU_NAME, new Integer(MENU_MNEMONIC), MENU_ICON);
    ctxMenuListener ctxMenuLstnr1 = new ctxMenuListener(rclickMi1, FILTER_CMD_ID);
    EditorManager.getEditorManager().getContextMenu().addContextMenuListener(ctxMenuLstnr1);
  }


  // cache EditorPane handle
  static BasicEditorPane currEditorPane = null;

  /**
   * Gets a handle to the current IDE editor pane.
   * Caches value in currEditorPane class static variable
   * @param oracle.ide.Context context - the JDeveloper IDE Context 
   * @return BasicEditorPane - handle to the IDE editor pane
   */
  static BasicEditorPane getCurrentEditorPane(Context context)
  {
    if (currEditorPane != null)
      return currEditorPane;

    BasicEditorPane editorPane = null;
    if (context != null)
    {
      View view = context.getView();
      FindableEditor findableEditor = null;
      if (view instanceof FindableEditor)
      {
        // If the current view is an editor itself, then check
        // if it supports the Find package.
        findableEditor = (FindableEditor)view;
      }
      // If the current view supports the find interface, get the
      // editor pane that has focus.
      if (findableEditor != null)
      {
        editorPane = findableEditor.getFocusedEditorPane();
      }
    }
    currEditorPane = editorPane;
    return currEditorPane;
  }

  /**
   * Test if menu item should be enabled (true if some text is presently selected in the IDE)
   * @param oracle.ide.Context context - the JDeveloper IDE Context 
   * @return boolean - whether to enable the menu item or not
   */
  private static boolean shouldMenuBeEnabled(Context context)
  {
    BasicEditorPane editor = getCurrentEditorPane(context);
    boolean bEnable = (editor.getSelectionStart() < editor.getSelectionEnd());
    return true; //bEnable;
  }

  /**
   * Main method to apply the filter
   * @param oracle.ide.Context context - the JDeveloper IDE Context 
   * @return boolean - true if the filter succeeded
   */
  private boolean doFilter(Context context)
  {
    boolean ret = false;
    BasicEditorPane editor = getCurrentEditorPane(context);
    if (editor != null)
    {
      try
      {
        String selectionText = editor.getSelectedText();
        if (selectionText == null) selectionText=""; // if nothing selected, make it an empty string
        // at present we don't invoke the filter if nothing selected
        if (selectionText.trim().length() > 0)
        {
          // get the Text Editor options
          ConfigData opts = (ConfigData) Ide.getSettings().getData(ConfigData.KEY);
          logMessage("Running filter: " + opts.getData());
          
          // invoke the external command
          //logMessage("Text selected:[" + selectionText + "]\n");
          String result = ExecShell.runShellCommand(opts.getData(), selectionText);
          //logMessage("Text replacement:[" + result + "]\n");
          
          editor.replaceSelection( result );          
          
          ret = true;
        }
        else
        {
          logMessage("No text selected");
          ret = false;
        }
      }
      catch (Exception ex)
      {
        logMessage(ex.toString());
      }
    }
    return ret;
  }

  /**
   * This method is called when a user interaction with a View triggers the execution of a command
   * @param oracle.ide.IdeAction action - action whose command is to be executed
   * @param oracle.ide.Context context - the JDeveloper IDE Context 
   * @return boolean - true if the event was handled
   */
  public boolean handleEvent(IdeAction action, Context context)
  {
    boolean bHandled = false;
    int cmdId = action.getCommandId();
    String msg = null;
    if (cmdId == FILTER_CMD_ID)
    {
      bHandled = true;
      if (doFilter(context))
        msg = "Filter applied";
      else
        msg = "Filter failure";
      Ide.getStatusBar().setText(msg);
    }
    return bHandled;
  }

  /**
   * This method updates the enabled status of the specified action within the specified context
   * @param oracle.ide.IdeAction action - action whose command is to be executed
   * @param oracle.ide.Context context - the JDeveloper IDE Context 
   * @return boolean - true if the event was handled
   */
  public boolean update(IdeAction action, Context context)
  {
    int cmdId = action.getCommandId();
    if (cmdId == FILTER_CMD_ID)
    {
      if (isMenuAvailable(context))
      {
        action.setEnabled(shouldMenuBeEnabled(context));
      }
      return true;
    }
    return false;
  }

  /**
   * Private ContextMenuListener class for add-in pop-up menu item
   * @version $Id: CodePaneAddin.java,v 1.5 2008/01/27 06:27:04 paulg Exp $
   * @author Paul Gallagher
   */
  private static final class ctxMenuListener
                  implements ContextMenuListener
  {
    private JMenuItem  menuItem;
    private int nCmdID;

    ctxMenuListener(JMenuItem  ctxMenuItem, int nCmdID)
    {
      this.menuItem = ctxMenuItem;
      this.nCmdID = nCmdID;
    }

    public void menuWillShow(ContextMenu popup)
    {
      Context context = (popup == null) ? null : popup.getContext();
      if (context == null)
        return;
      if (nCmdID != FILTER_CMD_ID)
        return;

      if (popup == EditorManager.getEditorManager().getContextMenu())
      {
        if (isMenuAvailable(context))
        {
          popup.add(this.menuItem);
        }
      }
      return;
    }

    public void menuWillHide(ContextMenu popup)
    {
    }

    public boolean handleDefaultAction(Context context)
    {
      return false;
    }
  }

  /**
   * Creates the filter menu item
   * @param Controller ctrlr - controller object
   * @param int cmdID - action command ID
   * @param String menuLabel - menu label
   * @param Integer mnemonic - shortcut key
   * @param String iconName - name of icon file (if any)
   * @return JMenuItem - the menu item
   */
  private static JMenuItem doCreateMenuItem(Controller ctrlr,
                                            int cmdID,
                                            String menuLabel,
                                            Integer mnemonic,
                                            String iconName)
  {
    Icon mi = ((iconName==null)?null:new ImageIcon(ctrlr.getClass().getResource(iconName)));
    IdeAction actionTM = IdeAction.get(cmdID,              // int cmdId,
                                          null,               //    String cmdClass,
                                          menuLabel,          //    String name,
                                          null,               //    KeyStroke accelerator,
                                          mnemonic,           //    Integer mnemonic,
                                          mi,                 //    Icon icon,
                                          null,               //    Object data,
                                          true                //    boolean enabled
                                         );
    actionTM.addController(ctrlr);
    JMenuItem menuItem = Ide.getMenubar().createMenuItem(actionTM);
    return menuItem;
  }

  /**
   * Restricts menu availability to only when text is in the editor context
   * @param oracle.ide.Context context - the JDeveloper IDE Context 
   * @return boolean - true if menu available
   */
  public static boolean isMenuAvailable(Context context)
  {
    boolean bAvail = false;
    Element el = context.getElement();
    if (el != null)
    {
      if (el instanceof TextNode) 
        bAvail = true;
    }
    return bAvail;
  }
  
  /**
   * Helper method to log a message to the IDE messages pane
   * @param String msg - the message to log 
   */
  private static final void logMessage(String msg)
  {
    LogManager.getLogManager().showLog();
    LogManager.getLogManager().getMsgPage().log(msg + "\n");
  }
}
