/* 
 *  Copyright (C) 2008, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id: ConfigData.java,v 1.2 2008/01/26 04:07:11 paulg Exp $
 */
package tardate.jdev.ide.filter;

import oracle.ide.config.ChangeEventSource;
import oracle.javatools.util.Copyable;

/**
 * Configuration data Java bean
 * 
 * @version $Id: ConfigData.java,v 1.2 2008/01/26 04:07:11 paulg Exp $
 * @author  Paul Gallagher
 */
public final class ConfigData
           extends ChangeEventSource
        implements Copyable
{
  public static final String KEY = "TardateFilterData";

  private static String DEFAULT_DATA = "<not set>";
  private String data  = DEFAULT_DATA;
  
  /*
   * Provide getters and setters for each field to set in setting.xml
   * Carefully use the JavaBean syntax.
   */
  public ConfigData()
  {
  }

  public Object copyTo(Object target)
  {
    final ConfigData copy =
       (target!=null?(ConfigData)target:new ConfigData());
    copyToImpl(copy);
    return copy;
  }

  protected final void copyToImpl(ConfigData copy)
  {
    copy.data   = data;
    copy.fireChangeEvent();
  }

  public String getData()
  {
    if (data.trim().equalsIgnoreCase(DEFAULT_DATA)) return "";
    return data;
  }

  public void setData(String d)
  {
    data = d.trim();
  }
}
