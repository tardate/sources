/* 
 *  Copyright (C) 2005, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id: ExecShell.java,v 1.7 2008/01/26 04:05:37 paulg Exp $
 */
 
package tardate.execshell;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;

import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Execute external process calls, with input/output handling.
 * 
 * See also:
 * http://www.devx.com/tips/Tip/14667
 * http://www.particle.kth.se/~lindsey/JavaCourse/Book/Part3/Chapter23/runExtProg.html
 *
 * @version $Id: ExecShell.java,v 1.7 2008/01/26 04:05:37 paulg Exp $
 * @author 	Paul Gallagher
 */
public class ExecShell 
{
  public ExecShell()
  {
  }

  /**
   * Run an operating system command, assumes no input
   * @param String theCmdLine - command line (supports double-quoted arguements)
   * @return String - is the command std output
   */
  public static String runShellCommand(String theCmdLine)
  throws java.io.IOException {
    return runShellCommand( theCmdLine, (BufferedReader)null);
  }

  /**
   * Run an operating system command with input string
   * @param String theCmdLine - command line (supports double-quoted arguements)
   * @param String send - command input
   * @return String - is the command std output
   */
  public static String runShellCommand(String theCmdLine, String send)
  throws java.io.IOException {
    return runShellCommand( theCmdLine,  new BufferedReader( new StringReader(send) ));
  }
  /**
   * Run an operating system command with buffered command input reader
   * @param String theCmdLine - command line (supports double-quoted arguements)
   * @param BufferedReader sendReader - buffered command input stream
   * @return String - is the command std output
   */
  public static String runShellCommand(String theCmdLine, BufferedReader sendReader) 
  throws java.io.IOException {
    Vector<String> theCmdArray = new Vector<String>(0);
    String REGEX = "\"([^\"]+?)\"\\s?|([^\\s]+)\\s?|\\s"; 
    Pattern p = Pattern.compile(REGEX);
    Matcher m = p.matcher(theCmdLine);
    while (m.find())
    {
      theCmdArray.add( m.group().trim() );
    }
    return runShellCommand( theCmdArray.toArray(new String[0]),  sendReader);
  }

  /**
   * Run an operating system command, assumes no input
   * @param String[] theCmdArray - command line arguements
   * @return String is the command std output
   */
  public static String runShellCommand(String[] theCmdArray) 
  throws java.io.IOException {
  	return runShellCommand(theCmdArray, (BufferedReader)null);
  }

  /**
   * Run an operating system command with input string
   * @param String[] theCmdArray - command line arguements
   * @param String send - command input
   * @return String is the command std output
   */
  public static String runShellCommand(String[] theCmdArray, String send)
  throws java.io.IOException {
  	return runShellCommand(theCmdArray, new BufferedReader( new StringReader(send) ) );
  }
  
  /**
   * Run an operating system command with input stream
   * @param String[] theCmdArray - command line arguements
   * @param InputStream send - command input stream
   * @return String is the command std output
   */
  public static String runShellCommand(String[] theCmdArray, InputStream send)
  throws java.io.IOException {
  	return runShellCommand(theCmdArray, new BufferedReader( new InputStreamReader(send) ) );
  }
          
  /**
   * Run an operating system command with buffered command input reader
   * @param String[] theCmdArray - command line arguements
   * @param BufferedReader sendReader - buffered command input stream
   * @return String is the command std output
   */
  public static String runShellCommand(String[] theCmdArray, BufferedReader sendReader) 
  throws java.io.IOException {
    StringBuffer sb = new StringBuffer(); 
    
    Runtime rtime = Runtime.getRuntime();
    Process child = rtime.exec(theCmdArray);

    if (sendReader!=null && sendReader.ready()) {
            
      // get output stream to write to the subprocess:
      BufferedWriter out = new BufferedWriter(new
        OutputStreamWriter( child.getOutputStream() ));

      String lineIn;
      while (( lineIn = sendReader.readLine ()) != null) {
        out.append(lineIn);out.newLine();
      }
      out.flush();
      out.close();
    }
    
   // get input stream to read back command output:
    BufferedReader in = new BufferedReader(new
      InputStreamReader(child.getInputStream()));

    String lineOut;
    while ((lineOut = in.readLine ()) != null) {
      sb.append(lineOut);
      if (in.ready()) sb.append('\n');
    }        

    // To get the return code from the shell script call:
    int retCode = child.exitValue();

    return sb.toString();
  }

  public static void main(String[] args)
  {
    try
    {
//      System.out.print( ExecShell.runShellCommand("ruby \"samples\\myrot13filter.rb\"", "filter this string") );
      System.out.print( ExecShell.runShellCommand(args, System.in) );
    } 
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }
}